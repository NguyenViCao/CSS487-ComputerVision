﻿#include "transform.h"
#include "Image.h"
#include <cmath>

//default constructor
Transform::Transform(Image input)
{
	this->input_ = input;
}

//----------------------------------------------------end of default constructor--------------------------------------------------------

// transform
// Preconditions:	input image passed in is correctly allocated/formatted
// Postconditions:	returns a new image that is transformed according to the six parameters that is read from the batch file (sx, sy, tx, ty, θ, and k)
//					p = R^(-1) * K^(-1) * S^(-1) * (q - t - c) + c
//					p is a point from the output image
//					R rotate by theta (angle)
//					K shear factor 
//					S two scale factors Sx, Sy
//					t translation tx, ty
//					c cols/2, rows/2
Image Transform::transform(const double& sx, const double& sy, const double& tx, const double& ty, const double& theta, const double& k, const Image& input)
{
	Image output(input.getRows(), input.getCols());

	// assign c(center)
	float cx = (float)input.getCols() / 2;
	float cy = (float)input.getRows() / 2;

	// Loop over all pixels and copy them into output image.
	// The output will be transformed accordingly to the six parameters that are passed in
	for (int row = 0; row < input.getRows(); row++) {
		for (int col = 0; col < input.getCols(); col++) {
			// assign p (point from the original image)

			// let a = q - t - c
			float ax = (float)col - tx - cx;
			float ay = (float)row - ty - cy;

			// calculating p1 = R^-1 * K^-1
			float px1 = (-k * cos(theta)) + cos(theta) + sin(theta);
			float py1 = (k * sin(theta)) - sin(theta) + cos(theta);

			// calculating p2 = p1 * S^-1
			// originally R^-1 * K^-1 * S^-1
			float px2 = (((-k * cos(theta)) + sin(theta)) / sy) + (cos(theta) / sx);
			float py2 = (((k * sin(theta)) + cos(theta)) / sy) - (sin(theta) / sx);

			// calculating p3 = p2 + p
			// originally R^-1 * K^-1 * S^-1 * (q - t - c)
			float px3 = ((cos(theta) / sx) * ax) + ((((-k * cos(theta)) + sin(theta)) / sy) * ay);
			float py3 = ((-sin(theta) / sx) * ax) + ((((k * sin(theta)) + cos(theta)) / sy) * ay);

			// update p3 += c
			// originally R^-1 * K^-1 * S^-1 * (q - t - c) + c
			px3 += cx;
			py3 += cy;

			if (0 < px3 && px3 <= input.getCols() && 0 < py3 && py3 <= input.getRows())
			{
				output.setPixel(row, col, input.getPixel(py3, px3));
			}
		}
	}
	return output;

}

//---------------------------------------------------end of transform function-------------------------------------------------------

// bilinear Interpolation function
// Preconditions:	pass in an image that has already gone through the linear transformation and get the correct color for that pixel
// Postconditions:	return a colored image that has been transformed 
Image Transform::bilinInter(const Image& input)
{
	Image output(input.getCols(), input.getRows());

	// Loop over all pixels and identify the original color of that pixel.
	// The output colored transformed image 
	for (int row = 0; row < input.getRows(); row++) {
		for (int col = 0; col < input.getCols(); col++) {
			double a = (double)output.getRows() - row;
			double b = (double)output.getCols() - col;
			// assign p (point from the original image)
			double pc = (1 - a) * (1 - b) * col + a * (1 - b) * ((double)col + 1) + (1 - a) * b * ((double)col + 1) + a * b * ((double)col + 1);
			double pl = (1 - a) * (1 - b) * row + a * (1 - b) * ((double)row + 1) + (1 - a) * b * (row)+a * b * ((double)row + 1);
			if (pc < 0 && 255 < pc && pl < 0 && 255 < pl)
			{
				output.setPixel(row, col, input.getPixel(0, 0));
			}
			output.setPixel(row, col, input.getPixel(pl, pc));
		}
	}
	return output;
}
//--------------------------------------------end of bilinear interpolstion function-------------------------------------------------